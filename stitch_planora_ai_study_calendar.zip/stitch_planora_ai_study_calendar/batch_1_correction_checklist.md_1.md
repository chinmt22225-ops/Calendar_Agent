# Planora Batch 1 Correction Checklist

| ID | Frame/Folder Name | screen.png | code.html | Exact Width | Exact Height | Vietnamese Only | Planora Brand Correct | Premium Removed | Help Removed | Digital Mentor Removed | Material Symbols Removed | Lucide Icons Used | Cropping Checked | Accessibility Checked | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| AUTH-01-V2 | AUTH-01-V2 — Đăng nhập (Sáng) | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| AUTH-01-D-V2 | AUTH-01-D-V2 — Đăng nhập (Tối) | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| AUTH-02-V2 | AUTH-02-V2 — Đang đăng nhập | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| AUTH-03-V2 | AUTH-03-V2 — Lỗi đăng nhập | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| AUTH-04-V2 | AUTH-04-V2 — Hết hạn phiên | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-01-V2 | SHELL-01-V2 — Lịch (Active) | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-02-V2 | SHELL-02-V2 — Trò chuyện (Active) | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-03-V2 | SHELL-03-V2 — Sự kiện sắp tới | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-04-V2 | SHELL-04-V2 — Không có sự kiện | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-05-V2 | SHELL-05-V2 — Menu người dùng | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-06-V2 | SHELL-06-V2 — Light Theme Baseline | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |
| SHELL-07-V2 | SHELL-07-V2 — Dark Theme Baseline | [ ] | [ ] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [ ] | [ ] | In Progress |

### Calendar Specific Requirements (for Shell-01, 03, 04, 05, 06, 07)
- [ ] Time gutter visible (56-64px)
- [ ] Hour labels visible (07:00 - 22:00)
- [ ] Half-hour grid visible
- [ ] All-day row visible (labeled "Cả ngày")
- [ ] Current-time line visible
- [ ] Events aligned to time grid
- [ ] "Tuần" tab matches Week View grid
