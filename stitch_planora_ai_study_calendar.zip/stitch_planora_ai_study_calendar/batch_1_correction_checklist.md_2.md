# Planora Batch 1 Correction Checklist

| ID | Frame/Folder Name | screen.png | code.html | Exact Width | Exact Height | Vietnamese Only | Planora Brand Correct | Premium Removed | Help Removed | Digital Mentor Removed | Material Symbols Removed | Lucide Icons Used | Cropping Checked | Accessibility Checked | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| AUTH-01-V2 | AUTH-01-V2 — Đăng nhập (Sáng) | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| AUTH-01-D-V2 | AUTH-01-D-V2 — Đăng nhập (Tối) | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| AUTH-02-V2 | AUTH-02-V2 — Đang đăng nhập | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| AUTH-03-V2 | AUTH-03-V2 — Lỗi đăng nhập | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| AUTH-04-V2 | AUTH-04-V2 — Hết hạn phiên | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-01-V2 | SHELL-01-V2 — Lịch (Active) | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-02-V2 | SHELL-02-V2 — Trò chuyện (Active) | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-03-V2 | SHELL-03-V2 — Sự kiện sắp tới | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-04-V2 | SHELL-04-V2 — Không có sự kiện | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-05-V2 | SHELL-05-V2 — Menu người dùng | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-06-V2 | SHELL-06-V2 — Light Theme Baseline | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |
| SHELL-07-V2 | SHELL-07-V2 — Dark Theme Baseline | [x] | [x] | 1440px | 1024px | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | [x] | Complete |

### Calendar Specific Requirements (for Shell-01, 03, 04, 05, 06, 07)
- [x] Time gutter visible (56-64px)
- [x] Hour labels visible (07:00 - 22:00)
- [x] Half-hour grid visible
- [x] All-day row visible (labeled "Cả ngày")
- [x] Current-time line visible
- [x] Events aligned to time grid
- [x] "Tuần" tab matches Week View grid
