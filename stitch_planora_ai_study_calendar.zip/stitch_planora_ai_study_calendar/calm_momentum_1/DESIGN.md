---
name: Calm Momentum
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f7'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#191c1e'
  on-surface-variant: '#444652'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f4'
  outline: '#757683'
  outline-variant: '#c5c5d4'
  surface-tint: '#3e58b5'
  primary: '#3b55b2'
  on-primary: '#ffffff'
  primary-container: '#556ecd'
  on-primary-container: '#fffbff'
  inverse-primary: '#b7c4ff'
  secondary: '#366852'
  on-secondary: '#ffffff'
  secondary-container: '#b6ebd0'
  on-secondary-container: '#3b6c56'
  tertiary: '#5f548a'
  on-tertiary: '#ffffff'
  tertiary-container: '#786da4'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001552'
  on-primary-fixed-variant: '#223f9b'
  secondary-fixed: '#b9eed2'
  secondary-fixed-dim: '#9dd2b7'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#1d503b'
  tertiary-fixed: '#e7deff'
  tertiary-fixed-dim: '#ccbefb'
  on-tertiary-fixed: '#1e1245'
  on-tertiary-fixed-variant: '#4a3f73'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e6'
  dark-bg: '#171A21'
  dark-surface: '#21252E'
  light-bg: '#F7F9FC'
  light-surface: '#FFFFFF'
  border-light: '#E2E8F0'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  sidebar-width: 280px
  chat-panel-width: 320px
---

## Brand & Style

The design system is centered on **Focus and Clarity**, specifically tailored for the academic and professional lifestyle of Vietnamese users. It employs a **Modern Corporate** aesthetic blended with **Soft Minimalism** to reduce cognitive load during intense planning sessions.

The visual identity prioritizes a "calm productivity" atmosphere. It avoids aggressive "hacker" aesthetics, opting instead for a trustworthy, approachable interface that feels like a supportive digital mentor. By utilizing generous whitespace and a refined color palette, the UI encourages long-form sessions without visual fatigue. The emotional response is one of **controlled momentum**—organized, steady, and highly capable.

## Colors

The palette uses a **Cool Slate** foundation to maintain a professional, academic tone across both Light and Dark modes.

- **Primary (Calm Blue):** Reserved for intentional actions, active states, and focus indicators.
- **Secondary (Sage) & Tertiary (Lilac):** Used for categorizing different subjects or projects. These should be applied at 15-20% opacity for container backgrounds with 100% opacity text for accessibility.
- **Dark Mode:** Implements a deep slate-tinted charcoal (`#171A21`) rather than pure black to preserve the "calm" brand attribute and reduce screen glare during late-night study sessions.
- **Semantic States:** Softened to prevent alarmist reactions. Error and warning states should feel like guidance rather than failure.

## Typography

This design system utilizes **Inter** exclusively to ensure maximum readability and a systematic, utilitarian feel.

- **Scale:** A compact scale is used to allow for the high information density required by complex grids and task lists.
- **Vietnamese Support:** All typography must accommodate Vietnamese diacritics. Ensure line heights are generous enough to prevent clipping of stacked marks (e.g., "ể", "ồ").
- **Hierarchy:** Use `label-caps` for headers and secondary metadata to create clear structural separation from user-generated content.
- **Weights:** Medium (500) and Semi-Bold (600) are preferred over Heavy (800+) weights to maintain a light and airy feel.

## Layout & Spacing

The layout follows an **8px linear scale** to ensure mathematical harmony.

- **Grid System:** Use a 12-column fluid grid for the main dashboard. The sidebar is fixed at 280px while the main content area expands.
- **Breakpoints:**
  - **Mobile (< 768px):** Single column, chat transitions to full-screen overlay, margins reduce to `md` (16px).
  - **Tablet (768px - 1024px):** Collapsible sidebar, fluid main area.
  - **Desktop (> 1024px):** Fixed sidebar, 12-column grid, page margins at `lg` (24px).
- **Rhythm:** Maintain a consistent `md` (16px) padding inside all cards and interactive containers.

## Elevation & Depth

Visual hierarchy is conveyed through **Tonal Layering**, using surface-on-surface tiers to create stacked depth without heavy visual weight.

- **Level 0 (Background):** Base layer (`#F7F9FC` in Light, `#171A21` in Dark).
- **Level 1 (Main Surface):** Card and container layer (White or `#21252E`).
- **Level 2 (Modals/Popovers):** These use a very soft ambient shadow: `0px 4px 20px rgba(0, 0, 0, 0.05)`.
- **Borders:** Use 1px solid borders (`#E2E8F0`) to define internal grids (like calendars) rather than shadows.
- **Interactive States:** Buttons and cards should use a slight "lift" effect (y-offset shadow) on hover to indicate playability.

## Shapes

The shape language is **Softly Geometric**, balancing professional structure with approachable corners.

- **Standard Radius:** 12px (defined as `rounded-md`) for buttons, input fields, and small cards.
- **Large Radius:** 16px (defined as `rounded-lg`) for sidebars and main content panels.
- **Pills:** Used for status badges, tags, and category indicators to distinguish them from actionable square-ish buttons.
- **Iconography:** Use **Lucide React** icons with a 2px stroke width. The rounded terminals of the icons are chosen to match the container corner radii.

## Components

- **Action Buttons:** Primary buttons use solid `#5F78D7` with white text. Secondary buttons are outlined with 1px borders.
- **Input Fields:** Use 12px rounding with 1px borders. Ensure focus states use the Primary color with a 2px outer glow.
- **Cards:** White or deep slate background with a 1px border. No shadows unless the card is being dragged or is a floating modal.
- **Chips & Tags:** Pill-shaped. For categories, use Secondary (Sage) or Tertiary (Lilac) at low opacity backgrounds.
- **Lists:** Clean rows with 1px bottom dividers. Interactive list items use a Primary 5% opacity tint on hover.
- **Checkboxes & Radios:** Use the Primary color for checked states. Checkboxes should have a 4px corner radius.
- **AI Chat Interface:** Chat bubbles for the AI should use a Primary tint (10% opacity) to differentiate from the neutral user bubbles.