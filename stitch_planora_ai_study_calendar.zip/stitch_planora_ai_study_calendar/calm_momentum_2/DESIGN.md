---
name: Calm Momentum
colors:
  surface: '#f8f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f8f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e7e8eb'
  surface-container-highest: '#e1e2e5'
  on-surface: '#191c1e'
  on-surface-variant: '#444652'
  inverse-surface: '#2e3133'
  inverse-on-surface: '#eff1f3'
  outline: '#757683'
  outline-variant: '#c5c5d4'
  surface-tint: '#3e58b5'
  primary: '#1f3c99'
  on-primary: '#ffffff'
  primary-container: '#3b55b2'
  on-primary-container: '#cad3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#3e58b5'
  on-secondary: '#ffffff'
  secondary-container: '#859eff'
  on-secondary-container: '#0e308e'
  tertiary: '#3e435b'
  on-tertiary: '#ffffff'
  tertiary-container: '#555b74'
  on-tertiary-container: '#ced3f1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001552'
  on-primary-fixed-variant: '#223f9b'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b7c4ff'
  on-secondary-fixed: '#001552'
  on-secondary-fixed-variant: '#223f9b'
  tertiary-fixed: '#dce1ff'
  tertiary-fixed-dim: '#c0c5e2'
  on-tertiary-fixed: '#151a30'
  on-tertiary-fixed-variant: '#40465e'
  background: '#f8f9fc'
  on-background: '#191c1e'
  surface-variant: '#e1e2e5'
  light-bg: '#F7F9FC'
  light-surface: '#FFFFFF'
  dark-bg: '#171A21'
  dark-surface: '#21252E'
  sage: '#366852'
  lilac: '#5F548A'
  border: '#E2E8F0'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  section-title:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-main:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  sidebar-width: 280px
---

## Brand & Style

The design system is centered on **Focus and Clarity**, specifically tailored for the academic lifestyle. It employs a **Modern Corporate** aesthetic blended with **Soft Minimalism** to reduce cognitive load during intense study planning.

The visual identity prioritizes a "calm productivity" atmosphere, moving away from aggressive tech aesthetics toward a trustworthy, approachable interface. By utilizing generous whitespace and a refined color palette, the UI encourages long-form planning sessions without visual fatigue. The emotional response is one of **controlled momentum**—organized, steady, and purposeful. The tone is strictly professional and student-centric, ensuring every element serves a functional purpose in the user's workflow.

## Colors

The palette uses a **Cool Slate** foundation to maintain a professional, academic tone.

- **Primary Action & Focus:** `#3B55B2` serves as the primary brand anchor. `#5F78D7` is used for high-visibility interactive actions, while `#DCE1FF` provides a soft focus tint for active states and highlights.
- **Categorization:** Sage and Lilac are reserved for categorizing study subjects or project types. These should be applied with 15-20% opacity for backgrounds paired with 100% opacity text to ensure AAA legibility.
- **Surfaces:** In Light mode, use `#F7F9FC` for page backgrounds and `#FFFFFF` for cards and panels. In Dark mode, transition to `#171A21` and `#21252E` respectively to reduce eye strain during late-night study.
- **Borders:** A consistent `#E2E8F0` defines structure without creating visual noise.

## Typography

This design system utilizes **Inter** exclusively to ensure maximum readability and a systematic, utilitarian feel.

- **Scale:** A compact scale is used to accommodate the high information density required by calendar grids and task lists. 
- **Hierarchy:** Screen titles use `display-lg` (24px) for clear orientation. Section headers utilize 16px to distinguish content groups, while 14px remains the standard for all primary interaction and reading.
- **Weights:** Semi-Bold (600) is preferred for headers to maintain a "light" and "airy" feel without losing structural emphasis.
- **Utility:** `label-caps` are reserved for metadata and calendar headers (e.g., days of the week) to create clear separation from user-generated content.

## Layout & Spacing

The layout follows an **8px linear scale** to ensure mathematical harmony across the interface.

- **Grid System:** A 12-column fluid grid drives the dashboard. The sidebar is fixed at 280px while the main workspace expands.
- **Adaptation:** On mobile, page margins reduce to 16px, and multi-column panels reflow into a single-column stack. Floating drawers transition to full-screen overlays to maximize touch targets.
- **Rhythm:** Consistent `md` (16px) padding is applied inside all containers, while `lg` (24px) is used for external page-level margins.

## Elevation & Depth

The design system uses **Tonal Layering** as the primary method of showing depth, supplemented by very soft shadows for floating elements.

- **Level 0 (Background):** Used for the base canvas of the application.
- **Level 1 (Main Surface):** Applied to cards, the main calendar grid, and sidebar containers.
- **Level 2 (Modals/Popovers):** These use a subtle ambient shadow: `0px 4px 20px rgba(0, 0, 0, 0.05)` to suggest elevation without heavy contrast.
- **Borders:** 1px solid borders define the grid and input boundaries. This maintains a "clean and flat" academic look that prioritizes content over container.
- **Interactions:** Use a subtle y-offset shadow on hover for buttons to indicate playability.

## Shapes

The shape language is **Softly Geometric**, balancing precision with approachability.

- **Standard Elements:** Buttons and input fields use a consistent 10-12px radius.
- **Containers:** Modals and large surface containers use a 14-16px radius to create a softer, more modern enclosure.
- **Icons:** Exclusively use **Lucide SVG** icons with a 2px stroke width. The rounded ends of the iconography harmonize with the corner radii of the UI elements.

## Components

- **Buttons:** Primary buttons use solid `#5F78D7` with white text. Focus states should employ a `#DCE1FF` halo or background tint. Secondary actions use outlined styles.
- **Inputs:** Maintain 10-12px corner radii. Use the Border color for default states and Primary for focused states.
- **Cards & Modals:** Modals must use 14-16px rounding. Content inside should be padded at 24px for desktop and 16px for mobile.
- **Lists:** Use subtle dividers and 14px text. Task lists include a "Check-off" animation that triggers a desaturation of the text.
- **Chips & Badges:** Use pill-shaped (fully rounded) containers for status indicators to distinguish them from actionable square-ish buttons.
- **Calendar:** The "Current Day" is highlighted with a 5% Primary tint and a 3px top-border. All grid lines are 1px solid using the Border color.