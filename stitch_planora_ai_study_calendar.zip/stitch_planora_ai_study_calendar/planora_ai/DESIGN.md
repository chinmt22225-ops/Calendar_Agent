---
name: Planora AI
colors:
  surface: '#faf9ff'
  surface-dim: '#d8d9e4'
  surface-bright: '#faf9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fe'
  surface-container: '#ecedf8'
  surface-container-high: '#e6e7f3'
  surface-container-highest: '#e0e2ed'
  on-surface: '#181b23'
  on-surface-variant: '#444652'
  inverse-surface: '#2d3039'
  inverse-on-surface: '#eff0fb'
  outline: '#757683'
  outline-variant: '#c5c5d4'
  surface-tint: '#3e58b5'
  primary: '#3b55b2'
  on-primary: '#ffffff'
  primary-container: '#556ecd'
  on-primary-container: '#fffbff'
  inverse-primary: '#b7c4ff'
  secondary: '#366852'
  on-secondary: '#ffffff'
  secondary-container: '#b6ebd0'
  on-secondary-container: '#3b6c56'
  tertiary: '#5f548a'
  on-tertiary: '#ffffff'
  tertiary-container: '#786da4'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001552'
  on-primary-fixed-variant: '#223f9b'
  secondary-fixed: '#b9eed2'
  secondary-fixed-dim: '#9dd2b7'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#1d503b'
  tertiary-fixed: '#e7deff'
  tertiary-fixed-dim: '#ccbefb'
  on-tertiary-fixed: '#1e1245'
  on-tertiary-fixed-variant: '#4a3f73'
  background: '#faf9ff'
  on-background: '#181b23'
  surface-variant: '#e0e2ed'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  calendar-cell-min-h: 120px
  sidebar-width: 280px
---

## Brand & Style

The design system is centered on **Focus and Clarity**, specifically tailored for the academic lifestyle of Vietnamese students. It employs a **Modern Corporate** aesthetic blended with **Soft Minimalism** to reduce cognitive load during intense study planning. 

The visual identity prioritizes a "calm productivity" atmosphere. It avoids aggressive "hacker" aesthetics often found in AI tools, opting instead for a trustworthy, approachable interface that feels like a supportive digital mentor. By utilizing generous whitespace and a refined color palette, the UI encourages long-form planning sessions without visual fatigue. The emotional response should be one of "controlled momentum"—organized, steady, and capable.

## Colors

The palette uses a **Cool Slate** foundation to maintain a professional, academic tone. 

- **Primary (Sky Blue):** Reserved for intentional actions, AI-driven suggestions, and the current day indicator in the calendar.
- **Secondary (Muted Sage) & Tertiary (Soft Lilac):** Used for categorizing different study subjects or project types. These colors should be used at 15-20% opacity for event backgrounds with 100% opacity text to ensure high legibility.
- **Semantic Colors:** Softened to prevent alarmist reactions. Error and warning states should feel like "guidance" rather than "failure."
- **Dark Mode:** Implements a deep navy-tinted charcoal rather than pure black to preserve the "calm" brand attribute and reduce screen glare during late-night study sessions.

## Typography

This design system utilizes **Inter** exclusively to ensure maximum readability and a systematic, utilitarian feel. 

- **Scale:** A compact scale is used to allow for the high information density required by calendar grids and task lists. 
- **Vietnamese Support:** Ensure the use of Inter’s standard glyphs for Vietnamese diacritics, maintaining consistent line height even with heavy stacking of marks (e.g., "ể", "ồ").
- **Hierarchy:** Use `label-caps` for calendar headers (days of the week) and secondary metadata to create clear structural separation from user-generated content.
- **Weights:** Medium (500) and Semi-Bold (600) are preferred over Bold (700) for standard interface elements to maintain a "light" and "airy" feel.

## Layout & Spacing

The layout follows an **8px linear scale** to ensure mathematical harmony across the desktop-first interface.

- **Grid System:** Use a 12-column grid for the main dashboard. The sidebar should be fixed (280px) while the main calendar area fluidly expands.
- **Calendar Grid:** Individual cells must have a minimum height to accommodate at least 3 stacked events before showing a "+ more" indicator. 
- **AI Chat Panel:** On desktop, this is a collapsible right-hand drawer (320px). On mobile, it transitions to a full-screen overlay.
- **Padding:** Maintain a consistent `md` (16px) padding inside all cards and modals. Use `lg` (24px) for page-level margins.

## Elevation & Depth

The design system uses **Tonal Layering** as the primary method of showing depth, supplemented by very soft shadows for floating elements.

- **Level 0 (Background):** `#F7F9FC` (Light) or `#171A21` (Dark).
- **Level 1 (Main Surface):** White or `#21252E`. Used for the main calendar grid and sidebar containers.
- **Level 2 (Modals/Popovers):** These use a subtle ambient shadow: `0px 4px 20px rgba(0, 0, 0, 0.05)`.
- **Borders:** Use 1px solid borders (`#E2E8F0`) to define the calendar grid rather than shadows. This maintains the "clean and flat" academic look.
- **Interactive States:** Buttons and interactive cards should use a slight "lift" effect (y-offset shadow) on hover to indicate playability.

## Shapes

The shape language is **Softly Geometric**. 

- **Standard Elements:** Buttons, input fields, and calendar events use a 10px radius (`rounded-md`).
- **Large Containers:** Sidebars and main content panels use a 14px radius (`rounded-lg`) to create a friendlier, modern enclosure.
- **Badges:** Upcoming event badges and status indicators use a fully rounded/pill shape to distinguish them from actionable buttons.
- **Icons:** Use **Lucide React** icons with a 2px stroke width. The rounded ends of the icons harmonize with the 10px-14px corner radii of the containers.

## Components

- **Calendar Grid:** Use thin `1px` borders. The "Current Day" should have a subtle background tint of Primary (5% opacity) and a bold top-border of Primary (3px).
- **AI Chat Interface:** Use a distinct background (Level 2 surface) to separate it from the calendar. Chat bubbles for the AI should use the Primary color at low opacity, while user bubbles stay neutral.
- **Action Buttons:** Primary buttons use a solid `#5F78D7` with white text. Secondary buttons are outlined.
- **Event Modals:** Use a clean, single-column layout for mobile and two-column for desktop. Focus on large, easy-to-tap inputs for Vietnamese text entry.
- **Upcoming Event Badges:** Use "Dot" indicators with the Secondary/Tertiary palette to show category without cluttering the monthly view.
- **Task List:** Includes a "Check-off" animation that triggers a slight desaturation of the text and a strikethrough.
- **Trash Panel:** A slide-out zone at the bottom-left for quick deletion of events via drag-and-drop.