# Planora AI Visual Coverage Checklist

## A. Authentication
- [x] AUTH-01 — Google OAuth login (Light) ({{DATA:SCREEN:SCREEN_158}})
- [x] AUTH-01-D — Google OAuth login (Dark) ({{DATA:SCREEN:SCREEN_154}})
- [x] AUTH-02 — Authentication loading ({{DATA:SCREEN:SCREEN_151}})
- [x] AUTH-03 — Authentication error ({{DATA:SCREEN:SCREEN_166}})
- [x] AUTH-04 — Expired session ({{DATA:SCREEN:SCREEN_149}})

## B. Shared Application Shell
- [x] SHELL-01 — Calendar active (Light) ({{DATA:SCREEN:SCREEN_218}})
- [x] SHELL-02 — Chat active (Light) ({{DATA:SCREEN:SCREEN_224}})
- [x] SHELL-03 — Upcoming-events popover ({{DATA:SCREEN:SCREEN_206}})
- [x] SHELL-04 — No upcoming events (Empty popover) ({{DATA:SCREEN:SCREEN_192}})
- [x] SHELL-05 — User menu (Settings, Logout) ({{DATA:SCREEN:SCREEN_222}})
- [x] SHELL-06 — Light theme baseline ({{DATA:SCREEN:SCREEN_232}})
- [x] SHELL-07 — Dark theme baseline ({{DATA:SCREEN:SCREEN_225}})

## C. Calendar Views
- [ ] CAL-01 — Week view (Existing: {{DATA:SCREEN:SCREEN_6}}) - *Update needed for viewport*
- [x] CAL-02 — Month view ({{DATA:SCREEN:SCREEN_6}})
- [ ] CAL-03 — Day view
- [ ] CAL-04 — Schedule/List view
- [ ] CAL-05 — Calendar loading state
- [ ] CAL-06 — Empty calendar state
- [ ] CAL-07 — Calendar API error
- [ ] CAL-08 — Event states (Hover/Selected)
- [ ] CAL-09 — Dragging event preview
- [ ] CAL-10 — Resizing event preview
- [ ] CAL-11 — Recurring event interaction warning

## D. Sidebar
- [ ] SIDEBAR-01 — Complete sidebar (Existing)
- [ ] SIDEBAR-02 — Collapsed sidebar
- [ ] SIDEBAR-03 — Mini-calendar interactive
- [ ] SIDEBAR-04 — Category filters (Show/Hide)

## E. Task Management (In Sidebar)
- [ ] TASK-01 — Populated task list
- [ ] TASK-02 — Create task form
- [ ] TASK-03 — Edit task form
- [ ] TASK-04 — Completed task state
- [ ] TASK-05 — Overdue task state
- [ ] TASK-06 — Empty task list
- [ ] TASK-07 — Task loading/error
- [ ] TASK-08 — Delete task confirmation

## F. Create & Edit Events (Modal)
- [x] EVENT-01 — Create event (Default) ({{DATA:SCREEN:SCREEN_9}})
- [ ] EVENT-02 — Create all-day event
- [ ] EVENT-03 — Daily recurrence settings
- [ ] EVENT-04 — Weekly recurrence settings
- [ ] EVENT-05 — Monthly recurrence settings
- [ ] EVENT-06 — Edit normal event
- [ ] EVENT-07 — Edit AI-generated event indicator
- [ ] EVENT-08 — Completed status
- [ ] EVENT-09 — Cancelled status
- [ ] EVENT-10 — Validation error states
- [ ] EVENT-11 — Saving state
- [ ] EVENT-12 — Save error state
- [ ] EVENT-13 — Delete event confirmation
- [ ] EVENT-14 — Recurrence edit scope selector

## G. Trash
- [x] TRASH-01 — Populated Trash ({{DATA:SCREEN:SCREEN_11}})
- [ ] TRASH-02 — Restore success state
- [ ] TRASH-03 — Permanent delete confirmation
- [ ] TRASH-04 — Empty Trash state
- [ ] TRASH-05 — Empty all confirmation
- [ ] TRASH-06 — Trash loading
- [ ] TRASH-07 — Trash API error

## H. AI Chat
- [x] CHAT-01 — Empty/New conversation (Light) ({{DATA:SCREEN:SCREEN_5}})
- [x] CHAT-02 — Populated conversation ({{DATA:SCREEN:SCREEN_12}})
- [ ] CHAT-03 — AI streaming state
- [ ] CHAT-04 — AI event action proposal card
- [ ] CHAT-05 — Successful action confirmation
- [ ] CHAT-06 — Chat error/Retry
- [ ] CHAT-07 — Gemini rate limit state
- [ ] CHAT-08 — Connection lost state
- [ ] CHAT-09 — Conversation loading
- [ ] CHAT-10 — No history state
- [ ] CHAT-11 — Rename conversation dialog
- [ ] CHAT-12 — Delete conversation dialog
- [ ] CHAT-13 — Conversation context menu

## I. Image Attachments
- [ ] IMAGE-01 — File selection trigger
- [ ] IMAGE-02 — Pasted image preview
- [ ] IMAGE-03 — Multiple image thumbnails (Max 3)
- [ ] IMAGE-04 — Drag and drop dropzone
- [ ] IMAGE-05 — Invalid format error
- [ ] IMAGE-06 — File size error (>4MB)
- [ ] IMAGE-07 — Max images error (>3)
- [ ] IMAGE-08 — Processing state

## J. Settings
- [x] SETTINGS-01 — Profile settings (Light) ({{DATA:SCREEN:SCREEN_3}})
- [ ] SETTINGS-01-D — Profile settings (Dark)
- [ ] SETTINGS-02 — Theme selection
- [ ] SETTINGS-03 — Saving state
- [ ] SETTINGS-04 — Success state
- [ ] SETTINGS-05 — Validation error
- [ ] SETTINGS-06 — API error

## K. System Components
- [ ] SYSTEM-01 — Toast variants (Success, Error, Info)
- [ ] SYSTEM-02 — Confirm dialogs (Standard, Destructive)
- [ ] SYSTEM-03 — Loading (Spinner, Skeleton)
- [ ] SYSTEM-04 — Global Empty states
- [ ] SYSTEM-05 — Form validation feedback
- [ ] SYSTEM-06 — Offline mode banner
- [ ] SYSTEM-07 — Accessibility focus ring samples

## L. Mobile Adaptation (390 x 844)
- [ ] MOBILE-01 — Calendar mobile view
- [ ] MOBILE-02 — Navigation drawer
- [ ] MOBILE-03 — Chat mobile
- [ ] MOBILE-04 — Chat with images
- [ ] MOBILE-05 — Event sheet (Bottom sheet)
- [ ] MOBILE-06 — Tasks mobile
- [ ] MOBILE-07 — Trash mobile
- [ ] MOBILE-08 — Settings mobile

## M. Dark Mode Samples
- [ ] CAL-01-D — Week view (Dark)
- [ ] CAL-02-D — Month view (Dark)
- [ ] CHAT-01-D — Chat empty (Dark)
- [ ] CHAT-02-D — Chat populated (Dark)
- [ ] EVENT-01-D — Event modal (Dark)
- [ ] TASK-01-D — Task panel (Dark)
- [ ] TRASH-01-D — Trash (Dark)
- [ ] SETTINGS-01-D — Settings (Dark)
- [x] AUTH-01-D — Login (Dark) ({{DATA:SCREEN:SCREEN_154}})
