# Planora Deferred Issues Ledger (Batch 1)

This document records unresolved issues from Batch 1 as identified at the start of Batch 2A. These issues are deferred for correction during the final refinement phase.

| ID | Issue Description | Originating Batch | Status |
| :--- | :--- | :--- | :--- |
| DEF-01 | AUTH-03-V2 is missing from the DataStore/Canvas. | Batch 1 | Deferred |
| DEF-02 | Batch 1 screenshots do not use the requested 1440×1024 viewport (some are larger). | Batch 1 | Deferred |
| DEF-03 | AUTH-01-V2 and AUTH-02-V2 are cropped in their screenshots. | Batch 1 | Deferred |
| DEF-04 | Light and Dark Calendar baselines (SHELL-06-V2/07-V2) do not match in content/layout. | Batch 1 | Deferred |
| DEF-05 | The Light/Dark comparison image (SHELL-COMP-V2) is invalid or inconsistent. | Batch 1 | Deferred |
| DEF-06 | Event cards are not perfectly aligned with their start/end times in some shell frames. | Batch 1 | Deferred |
| DEF-07 | "Digital Mentor" branding persists in some Batch 1 frames. | Batch 1 | Deferred |
| DEF-08 | "Trợ giúp" (Help) navigation persists in some Batch 1 frames. | Batch 1 | Deferred |
| DEF-09 | Material Symbols are still used in some Batch 1 icons instead of Lucide. | Batch 1 | Deferred |
| DEF-10 | English calendar labels (e.g., "October", "Mon") persist in some Batch 1 frames. | Batch 1 | Deferred |
| DEF-11 | Brand naming is inconsistent (Planora vs Planora AI in headers). | Batch 1 | Deferred |
| DEF-12 | Batch 1 completion checklists conflict with actual exported files. | Batch 1 | Deferred |